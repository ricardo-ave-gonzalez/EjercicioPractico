import { Component } from '@angular/core';



@Component({
    selector: 'componente-loco',
    templateUrl: './mi-componente.component.html'
})
export class MiComponente{
    titulo:string = "Hola desde una variable de Angular!";
}
