export class EstudianteEntity {
    constructor(public nombre:string,public apellido:string){}
}

