import { EstudianteEntity } from './estudiante-entity';

describe('EstudianteEntity', () => {
  it('should create an instance', () => {
    expect(new EstudianteEntity()).toBeTruthy();
  });
});
