import { Pelicula } from './interfaces';

export const PELICULAS: Pelicula[] = [
    {id_pelicula:1,titulo:"El club de los malditos",director:'Nicanor Gonzalez',genero:1,id_genero:1,foto:'assets/img/malditos.jpg'},
    {id_pelicula:2,titulo:"The Story of Ferdinand",director:'Alfredo Perez',genero:2,id_genero:2,foto:'assets/img/ferdinand.jpg'},
    {id_pelicula:3,titulo:"Pendular",director:'Marisa Rodriguez',genero:3,id_genero:3,foto:'assets/img/pendular.jpg'},
]