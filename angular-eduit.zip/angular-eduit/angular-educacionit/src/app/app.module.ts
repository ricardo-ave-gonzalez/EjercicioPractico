import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http'
import { AppComponent } from './app.component';
import { MiComponente } from './mi-componente/mi-componente.component';
import { ListadoComponent } from './listado/listado.component';
import { DetalleComponent } from './detalle/detalle.component';
import { ReactivoComponent } from './Formularios/reactivo/reactivo.component';
import { DrivenComponent } from './Formularios/driven/driven.component';
import { FormDrivenComponent } from './validados/form-driven/form-driven.component';
import { ListadoPeliculaComponent } from './Peliculas/listado/listado.component';
import { DetallePeliculasComponent } from './Peliculas/detalle-peliculas/detalle-peliculas.component';
import { EliminarDatosComponent } from './Peliculas/eliminar-datos/eliminar-datos.component';
@NgModule({
  declarations: [
    AppComponent,
    MiComponente,
    ListadoComponent,
    DetalleComponent,
    ReactivoComponent,
    DrivenComponent,
    FormDrivenComponent,
    ListadoPeliculaComponent,
    DetallePeliculasComponent,
    EliminarDatosComponent,
    
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
