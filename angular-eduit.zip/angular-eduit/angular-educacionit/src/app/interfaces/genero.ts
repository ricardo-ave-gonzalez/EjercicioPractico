export interface Genero {
    id_genero:number;
    descripcion:string;
}
