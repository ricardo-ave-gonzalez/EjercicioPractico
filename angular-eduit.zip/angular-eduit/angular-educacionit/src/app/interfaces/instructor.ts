export interface Instructor {
}
