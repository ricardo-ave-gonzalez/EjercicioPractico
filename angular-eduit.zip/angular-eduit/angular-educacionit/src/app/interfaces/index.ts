
export * from './estudiante';
export * from './instructor';
export * from './estudiante-form';
export * from './pelicula';
export * from './genero';