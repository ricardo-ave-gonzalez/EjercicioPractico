export interface Estudiante {
    nombre:string;
    legajo:number;
    materia:string;
    regular:boolean;
}
