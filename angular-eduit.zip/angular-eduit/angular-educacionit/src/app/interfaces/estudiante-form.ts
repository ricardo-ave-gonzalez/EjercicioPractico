export interface EstudianteForm {
    nombre:string;
    apellido:string;
}
