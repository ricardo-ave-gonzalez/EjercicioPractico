export interface Pelicula {
    id_pelicula:number;
    titulo:string;
    director:string;
    genero:number;
    id_genero:number;
    foto: string;
}
