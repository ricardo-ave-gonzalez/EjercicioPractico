import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { PeliculaService } from './../../Servicios/pelicula.service';

@Component({
  selector: 'app-eliminar-datos',
  templateUrl: './eliminar-datos.component.html',
  styleUrls: ['./eliminar-datos.component.css']
})
export class EliminarDatosComponent implements OnInit {
  data: string;
  constructor(private svcPelicula: PeliculaService) { }

  ngOnInit(): void {
  }

  eliminarPelicula(){
    this.svcPelicula.deletePelicula(1)
    .subscribe(() => this.data = "Datos borrados correctamente", error => this.data = error)
  }
}
