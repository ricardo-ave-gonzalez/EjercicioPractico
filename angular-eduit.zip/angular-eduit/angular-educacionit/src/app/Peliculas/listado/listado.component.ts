import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { PeliculaService } from './../../Servicios/pelicula.service';
import { Pelicula } from './../../interfaces';

@Component({
  selector: 'app-listado-pelicula',
  templateUrl: './listado.component.html',
  styleUrls: ['./listado.component.css']
})
export class ListadoPeliculaComponent implements OnInit {
  data:string;
  titulo:string = "Listado de Películas";
  pelicula:any;
  peliculas:Pelicula[];
  idPeliculaSeleccion:number;
  updateOK:boolean = false;
  
  @Output()
  eliminar = new EventEmitter();

  constructor(private svcPelicula:PeliculaService) { }

  ngOnInit(): void {
    this.obtenerPeliculas();
  }

  obtenerPeliculas(){
    this.svcPelicula.getPeliculas().subscribe(z => this.peliculas = z)
  }

  seleccionarPelicula(id_pelicula:number){
    this.idPeliculaSeleccion = id_pelicula;
  }

  volverAtras(estado){
    this.obtenerPeliculas();
    this.idPeliculaSeleccion = estado;
  }
  guardadoOk(estado){
    if(estado){
      this.idPeliculaSeleccion = null;
      this.updateOK = true;
    }
  }
  eliminarPelicula(pelicula:Pelicula){
    /*if(!pelicula)return;
    this.svcPelicula.deletePelicula(pelicula.id_genero)
    .subscribe(
      rs => console.log(rs),
      er => console.log(er),
      () => {
        this.peliculas = this.peliculas.filter(z => z !== pelicula)
      }
    )*/
    this.svcPelicula.deletePelicula(pelicula.id_pelicula)
      .subscribe(z => z !== pelicula)
      console.log(`Se elimino el id: ${pelicula.id_pelicula}`);
      this.eliminar.emit(true);
    //
    //this.svcPelicula.deletePelicula(1)
    //  .subscribe(() => this.data = "Datos borrados correctamente", error => this.data = error);
    //
    /*this.svcPelicula.deletePelicula(pelicula.id_genero)
      .subscribe(
        z => {
          if(z == true){
            this.peliculas.pop()
          }
        }
      )*/
      //this.svcPelicula.deletePelicula(1)
      //  .subscribe(() => this.data = "Datos borrados correctamente", er => this.data = er);
  } 
}
