import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { Pelicula, Genero } from './../../interfaces';
import { HttpClient } from '@angular/common/http';
import { PeliculaService } from './../../Servicios/pelicula.service';
//import { EventEmitter } from 'events';

@Component({
  selector: 'app-detalle-peliculas',
  templateUrl: './detalle-peliculas.component.html',
  styleUrls: ['./detalle-peliculas.component.css']
})
export class DetallePeliculasComponent implements OnInit {
  @Input()
  id_pelicula:number;
  //pelicula:Pelicula;
  pelicula:any;
  peliculas:Pelicula[];
  generos:Genero[];
  data:string;

  @Output()
  cancelar = new EventEmitter();

  @Output()
  guardar = new EventEmitter();

  @Output()
  eliminar = new EventEmitter();
  
  constructor(private svcPelicula: PeliculaService) { }

  ngOnInit(): void {
    this.obtenerPeliculas();
    this.obtenerGenero();
  }

  obtenerPeliculas(){
    this.svcPelicula.getPeliculaPorId(this.id_pelicula)
      .subscribe(z => this.pelicula = z);
  }
  
  obtenerGenero(){
    this.svcPelicula.getGenero()
      .subscribe(z => this.generos = z);
  }

  cancelarEdicion(){
    this.cancelar.emit(true)
  }

  guardarCambios(){
    this.svcPelicula.actualizarPelicula(this.pelicula)
      .subscribe(data => {
        if(data.affectedRows === 1){
          console.log("Bien ahi")
          this.guardar.emit(true);
        }
      })
  }

  eliminarPelicula(pelicula:Pelicula){
    /*if(!pelicula)return;
    this.svcPelicula.deletePelicula(pelicula.id_genero)
    .subscribe(
      rs => console.log(rs),
      er => console.log(er),
      () => {
        this.peliculas = this.peliculas.filter(z => z !== pelicula)
      }
    )*/
    this.svcPelicula.deletePelicula(pelicula.id_pelicula)
      //.subscribe(() => this.data = "Datos borrados correctamente", error => this.data = error);
      .subscribe(z => z !== pelicula);
      console.log(`Se elimino el id: ${pelicula.id_pelicula}`)
      this.eliminar.emit(true);
  }
}
