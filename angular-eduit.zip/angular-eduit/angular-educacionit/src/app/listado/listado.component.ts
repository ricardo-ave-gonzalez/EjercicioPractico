import { Component, OnInit } from '@angular/core';

import { Estudiante } from './../interfaces/';

const ESTUDIANTES:Array<Estudiante> = [
  {nombre: 'Maria Perez',legajo:123,materia:'PHP',regular:true},
  {nombre: 'Roberto Gonzalez',legajo:456,materia:'Angular',regular:true},
  {nombre: 'Andrea Ramirez',legajo:789,materia:'C#',regular:true}
]

@Component({
  selector: 'app-listado',
  templateUrl: './listado.component.html',
  styleUrls: ['./listado.component.css']
})
export class ListadoComponent implements OnInit {
  estudiantes:Array<Estudiante> = ESTUDIANTES;
  estudianteSeleccionado:Estudiante;
  constructor() {
    console.log("se cargó el componente")
   }

  ngOnInit(): void {
    console.log("se cargó el componente")
  }

  verDetalleEstudiante(estudiante:Estudiante): void{
    if(window.confirm("Estas seguro que queres editar al estudiante?")){
      this.estudianteSeleccionado = estudiante
    }
  }

}


/*
class Persona{

  nombre
  apellido
  
  constructor(nombre,apellido){
    this.nombre = nombre
    this.apellido = apellido
  }
}

var p = new Persona("Maria","Perez")
var j = new Persona("Gonzalo","Rodriguez")
*/