import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-reactivo',
  templateUrl: './reactivo.component.html',
  styleUrls: ['./reactivo.component.css']
})
export class ReactivoComponent implements OnInit {
  titulo="Formulario Reactivo";
  // private fn = new FormBuilder()
  constructor(private fn: FormBuilder) { }

  ngOnInit(): void {
  }

  /*formAngular = new FormGroup({
    alfajor: new FormControl('Gabriela',Validators.required),
    hamburguesa: new FormControl('')
  })*/
  formAngular = this.fn.group({
    alfajor: [''],
    hamburguesa:['Perez']
  })

  onSubmit():void{
    console.warn('Enviado!')
  }

  actualizate():void{
    this.formAngular.patchValue({
      alfajor: 'Matildo',
      hamburguesa: 'Perez'
    })
  }

}
