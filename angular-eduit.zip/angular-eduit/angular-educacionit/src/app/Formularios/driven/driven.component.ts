import { Component, OnInit } from '@angular/core';
import { EstudianteForm } from './../../interfaces';
import { EstudianteEntity } from './../../entidades/estudiante-entity';


@Component({
  selector: 'app-driven',
  templateUrl: './driven.component.html',
  styleUrls: ['./driven.component.css']
})
export class DrivenComponent implements OnInit {
  titulo = "Formularios Template Driven"
  estudiante: EstudianteEntity;
  constructor() { 
    //this.estudiante = {nombre:'Carla',apellido:"Perez"}
    this.estudiante = new EstudianteEntity('Carla','¨Perez');
  }

  ngOnInit(): void {
  }

  onSubmit(){
    console.warn("Formulario enviado")
  }

}
