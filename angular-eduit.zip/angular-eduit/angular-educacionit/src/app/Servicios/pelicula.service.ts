import { Injectable } from '@angular/core';
import { Observable, Observer, throwError } from 'rxjs';
import { Pelicula, Genero } from './../interfaces';
import { PELICULAS } from './../mock-peliculas';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { catchError } from 'rxjs/operators';

const httpOptions = {
  headers: new HttpHeaders({//siempre va a pedir en el parametro un objeto
    'Content-Type': 'application/json',
    'Authorization': 'my-auth-token'
  })
}

@Injectable({
  providedIn: 'root'
})
export class PeliculaService {

  private urlPeliculas = 'http://localhost:3001/angular5/peliculas/';
  private urlGeneros = 'http://localhost:3001/angular5/generos/';

  constructor(private http: HttpClient) { }

  getPeliculas(): Observable<Pelicula[]> {
    /*return new Observable((observer: Observer<Pelicula[]>) => {
      observer.next(PELICULAS);
      observer.complete();
    })
    */
    const respuesta = this.http.get<Pelicula[]>(`${this.urlPeliculas}`);
    return respuesta;
  }

  getPeliculaPorId(id_pelicula: number): Observable<Pelicula> {
    return this.http.get<Pelicula>(`${this.urlPeliculas}${id_pelicula}`);
  }

  getGenero(): Observable<Genero[]> {
    return this.http.get<Genero[]>(`${this.urlGeneros}`);
  }

  actualizarPelicula(pelicula: Pelicula): Observable<any> {
    return this.http.put(`${this.urlPeliculas}${pelicula.id_pelicula}`, pelicula,
      httpOptions).pipe(catchError(this.manejarError)
      );
  }

  deletePelicula(id: number): Observable<{}> {
    const url = `${this.urlPeliculas}${id}`;
    return this.http.delete(url, httpOptions)
      .pipe(
        catchError(this.handleError)
      )
  }

  private manejarError(error: HttpErrorResponse) {
    console.log(`El backend retornó el código ${error.status}, el cuerpo del mensaje es ${error.message}`);
    return throwError("Algo salio mal, intenta mas tarde");
  }

  private handleError(error: HttpErrorResponse){
    if(error.error instanceof ErrorEvent){
      console.error('Ocurrió un error: ', error.error.message);
    }else{
      console.error(`El backend retornó el código ${error.status}, El cuerpo del mensaje de error es: ${error.message}`);
    }
    return throwError('Algo malo sucedió; por favor intente más tarde');
  }

}
