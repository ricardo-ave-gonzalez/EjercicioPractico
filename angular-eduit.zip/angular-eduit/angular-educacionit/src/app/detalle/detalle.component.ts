import { Component, Input, OnInit } from '@angular/core';
import {Estudiante,Instructor} from './../interfaces/'

@Component({
  selector: 'app-detalle',
  templateUrl: './detalle.component.html',
  styleUrls: ['./detalle.component.css']
})
export class DetalleComponent implements OnInit {
  titulo:string = "Modificar Estudiante"

  @Input()
  estudiante:Estudiante  
  
  constructor() { }

  ngOnInit(): void {
    console.log(this.estudiante)
  }

  mostrarEstudiante():void{
    console.log(this.estudiante)
  }

}
